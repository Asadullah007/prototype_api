let submit = document.getElementById('submit');

submit.addEventListener('click', (e) => {
  e.preventDefault();

  const data = fetch('http:localhost:5000/api/predict')
    .then(res => {
      res = res.json().data;
      swal({
        title: "Result",
        text: `The prediction of model is ${res}`,
        button: "Ok"
      });
    })
    .catch(err => {
      swal({
        title: "Error",
        text: err
      })
    });
})